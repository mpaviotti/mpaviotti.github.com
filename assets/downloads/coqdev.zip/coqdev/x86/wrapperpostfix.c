  ;
  { VOIDFUN vf = (VOIDFUN) cresult; (*vf)(); }
}
