typedef void (*VOIDFUN)();
typedef char carray[];
void EntryPoint() {
  int CArray = 3;
  int dummy = 0;
  carray 
